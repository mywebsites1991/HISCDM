The detailed processes of using the code（WEKA 3.6）：
1、Put HISCDM.java into directory: weka.classifiers.*
2、Run WEKA, choose Experimenter/Explorer window, add the datasets, choose classifiers.*.HISCDM algorithm, then click "start". 